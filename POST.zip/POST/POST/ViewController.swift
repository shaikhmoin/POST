//
//  ViewController.swift
//  POST
//
//  Created by MACOS on 6/14/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    var final = [Any]()
    let picker = UIImagePickerController()
    
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var tblview: UITableView!
    @IBOutlet var imgview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/test/select.php")
        
        let url = URL(string: str!)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
          
            //let str1 = String(data: data!, encoding: String.Encoding.utf8)
            //print(str1 ?? "")
            
            do
            {
                let dic = try JSONSerialization.jsonObject(with: data!, options: []) as! [Any]
                
                for item in dic
                {
                    self.final.append(item)
                    self.tblview.reloadData()
                }
                
            }
            catch
            {
                
            }
        })
        datatask.resume()
    }
    
    
    @IBAction func btnPickImage(_ sender: Any) {
        picker.sourceType = (UIImagePickerControllerSourceType.photoLibrary)
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imgview.image = info[UIImagePickerControllerOriginalImage] as! UIImage
        self.dismiss(animated: true, completion: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
        
        cell?.textLabel?.text = dicfinal["Name"] as! String
        cell?.detailTextLabel?.text = dicfinal["Address"] as! String
        
        return cell!
    }

    @IBAction func btnInsert(_ sender: Any) {
        let str = String("http://localhost/test/insert.php")
        
        let param = String("Name=\(txtname.text!)&Address=\(txtadd.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Cnntent-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
          
            let str1 = String(data: data!, encoding: String.Encoding.utf8)
            print(str1 ?? "")
           
            
            
        })
        
        let nav = self.storyboard?.instantiateViewController(withIdentifier: "next") as! First
        nav.str = final
        nav.img = imgview.image!
        self.navigationController?.pushViewController(nav, animated: true)
        datatask.resume()
    }

}

