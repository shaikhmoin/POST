-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 14, 2017 at 09:55 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EMP`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblemp`
--

CREATE TABLE IF NOT EXISTS `tblemp` (
  `Id` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemp`
--

INSERT INTO `tblemp` (`Id`, `Name`, `Address`) VALUES
(1, 'moin', 'surat'),
(2, 'hiii', 'hiii'),
(3, 'dddd', 'dddd'),
(6, 'ggg', 'ssd'),
(7, 'ggg', 'ggg'),
(8, 'he', 'gg'),
(12, 'd', 'd'),
(13, 'lll', 'hhhhh'),
(14, 'vishal', 'surat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblemp`
--
ALTER TABLE `tblemp`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblemp`
--
ALTER TABLE `tblemp`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;--
-- Database: `Moin`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblemp`
--

CREATE TABLE IF NOT EXISTS `tblemp` (
  `ID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=315 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemp`
--

INSERT INTO `tblemp` (`ID`, `Name`, `Address`, `Mobile`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, 'moin', 'surat', '9228833994'),
(4, '', '', ''),
(5, 'anil', 'st', '4545'),
(6, 'anil', 'st', '4545'),
(7, 'dd', 'dd', '2342'),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', ''),
(11, 'hh', 'kkkkkjjjj', '88888'),
(12, '', '', ''),
(13, '', '', ''),
(14, '', '', ''),
(15, '', '', ''),
(16, '', '', ''),
(17, '', '', ''),
(18, '', '', ''),
(19, '', '', ''),
(20, '', '', ''),
(21, '', '', ''),
(22, '', '', ''),
(23, '', '', ''),
(24, '', '', ''),
(25, '', '', ''),
(26, '', '', ''),
(27, '', '', ''),
(28, '', '', ''),
(29, '', '', ''),
(30, '', '', ''),
(31, '', '', ''),
(32, '', '', ''),
(33, '', '', ''),
(34, '', '', ''),
(35, '', '', ''),
(36, '', '', ''),
(37, '', '', ''),
(38, '', '', ''),
(39, '', '', ''),
(40, '', '', ''),
(41, '', '', ''),
(42, '', '', ''),
(43, '', '', ''),
(44, '', '', ''),
(45, '', '', ''),
(46, '', '', ''),
(47, '', '', ''),
(48, '', '', ''),
(49, '', '', ''),
(50, '', '', ''),
(51, '', '', ''),
(52, '', '', ''),
(53, '', '', ''),
(54, '', '', ''),
(55, '', '', ''),
(56, '', '', ''),
(57, '', '', ''),
(58, '', '', ''),
(59, '', '', ''),
(60, '', '', ''),
(61, '', '', ''),
(62, '', '', ''),
(63, '', '', ''),
(64, '', '', ''),
(65, '', '', ''),
(66, '', '', ''),
(67, '', '', ''),
(68, '', '', ''),
(69, '', '', ''),
(70, '', '', ''),
(71, '', '', ''),
(72, '', '', ''),
(73, '', '', ''),
(74, '', '', ''),
(75, '', '', ''),
(76, '', '', ''),
(77, '', '', ''),
(78, '', '', ''),
(79, '', '', ''),
(80, '', '', ''),
(81, '', '', ''),
(82, '', '', ''),
(83, '', '', ''),
(84, '', '', ''),
(85, '', '', ''),
(86, '', '', ''),
(87, '', '', ''),
(88, '', '', ''),
(89, '', '', ''),
(90, '', '', ''),
(91, '', '', ''),
(92, '', '', ''),
(93, '', '', ''),
(94, '', '', ''),
(95, '', '', ''),
(96, '', '', ''),
(97, '', '', ''),
(98, '', '', ''),
(99, '', '', ''),
(100, '', '', ''),
(101, '', '', ''),
(102, '', '', ''),
(103, '', '', ''),
(104, '', '', ''),
(105, '', '', ''),
(106, '', '', ''),
(107, '', '', ''),
(108, '', '', ''),
(109, '', '', ''),
(110, '', '', ''),
(111, '', '', ''),
(112, '', '', ''),
(113, '', '', ''),
(114, '', '', ''),
(115, '', '', ''),
(116, '', '', ''),
(117, '', '', ''),
(118, '', '', ''),
(119, '', '', ''),
(120, '', '', ''),
(121, '', '', ''),
(122, '', '', ''),
(123, '', '', ''),
(124, '', '', ''),
(125, '', '', ''),
(126, '', '', ''),
(127, '', '', ''),
(128, '', '', ''),
(129, '', '', ''),
(130, '', '', ''),
(131, '', '', ''),
(132, '', '', ''),
(133, '', '', ''),
(134, '', '', ''),
(135, '', '', ''),
(136, '', '', ''),
(137, '', '', ''),
(138, '', '', ''),
(139, '', '', ''),
(140, '', '', ''),
(141, '', '', ''),
(142, '', '', ''),
(143, '', '', ''),
(144, '', '', ''),
(145, '', '', ''),
(146, '', '', ''),
(147, '', '', ''),
(148, '', '', ''),
(149, '', '', ''),
(150, '', '', ''),
(151, '', '', ''),
(152, '', '', ''),
(153, '', '', ''),
(154, '', '', ''),
(155, '', '', ''),
(156, '', '', ''),
(157, '', '', ''),
(158, '', '', ''),
(159, '', '', ''),
(160, '', '', ''),
(161, '', '', ''),
(162, '', '', ''),
(163, '', '', ''),
(164, '', '', ''),
(165, '', '', ''),
(166, '', '', ''),
(167, '', '', ''),
(168, '', '', ''),
(169, '', '', ''),
(170, '', '', ''),
(171, '', '', ''),
(172, '', '', ''),
(173, '', '', ''),
(174, '', '', ''),
(175, '', '', ''),
(176, '', '', ''),
(177, '', '', ''),
(178, '', '', ''),
(179, '', '', ''),
(180, '', '', ''),
(181, '', '', ''),
(182, '', '', ''),
(183, '', '', ''),
(184, '', '', ''),
(185, '', '', ''),
(186, '', '', ''),
(187, '', '', ''),
(188, '', '', ''),
(189, '', '', ''),
(190, '', '', ''),
(191, '', '', ''),
(192, '', '', ''),
(193, '', '', ''),
(194, '', '', ''),
(195, '', '', ''),
(196, '', '', ''),
(197, '', '', ''),
(198, '', '', ''),
(199, '', '', ''),
(200, '', '', ''),
(201, '', '', ''),
(202, '', '', ''),
(203, '', '', ''),
(204, '', '', ''),
(205, '', '', ''),
(206, '', '', ''),
(207, '', '', ''),
(208, '', '', ''),
(209, '', '', ''),
(210, '', '', ''),
(211, '', '', ''),
(212, '', '', ''),
(213, '', '', ''),
(214, '', '', ''),
(215, '', '', ''),
(216, '', '', ''),
(217, '', '', ''),
(218, '', '', ''),
(219, '', '', ''),
(220, '', '', ''),
(221, '', '', ''),
(222, '', '', ''),
(223, '', '', ''),
(224, '', '', ''),
(225, '', '', ''),
(226, '', '', ''),
(227, '', '', ''),
(228, '', '', ''),
(229, '', '', ''),
(230, '', '', ''),
(231, '', '', ''),
(232, '', '', ''),
(233, '', '', ''),
(234, '', '', ''),
(235, '', '', ''),
(236, '', '', ''),
(237, '', '', ''),
(238, '', '', ''),
(239, '', '', ''),
(240, '', '', ''),
(241, '', '', ''),
(242, '', '', ''),
(243, '', '', ''),
(244, '', '', ''),
(245, '', '', ''),
(246, '', '', ''),
(247, '', '', ''),
(248, '', '', ''),
(249, '', '', ''),
(250, '', '', ''),
(251, '', '', ''),
(252, '', '', ''),
(253, '', '', ''),
(254, '', '', ''),
(255, '', '', ''),
(256, '', '', ''),
(257, '', '', ''),
(258, '', '', ''),
(259, '', '', ''),
(260, '', '', ''),
(261, '', '', ''),
(262, '', '', ''),
(263, '', '', ''),
(264, '', '', ''),
(265, '', '', ''),
(266, '', '', ''),
(267, '', '', ''),
(268, '', '', ''),
(269, '', '', ''),
(270, '', '', ''),
(271, '', '', ''),
(272, '', '', ''),
(273, '', '', ''),
(274, '', '', ''),
(275, '', '', ''),
(276, '', '', ''),
(277, '', '', ''),
(278, '', '', ''),
(279, '', '', ''),
(280, '', '', ''),
(281, '', '', ''),
(282, '', '', ''),
(283, '', '', ''),
(284, '', '', ''),
(285, '', '', ''),
(286, '', '', ''),
(287, '', '', ''),
(288, '', '', ''),
(289, '', '', ''),
(290, '', '', ''),
(291, '', '', ''),
(292, '', '', ''),
(293, '', '', ''),
(294, '', '', ''),
(295, '', '', ''),
(296, '', '', ''),
(297, '', '', ''),
(298, '', '', ''),
(299, '', '', ''),
(300, '', '', ''),
(301, '', '', ''),
(302, '', '', ''),
(303, '', '', ''),
(304, '', '', ''),
(305, '', '', ''),
(306, '', '', ''),
(307, '', '', ''),
(308, '', '', ''),
(309, '', '', ''),
(310, '', '', ''),
(311, '', '', ''),
(312, '', '', ''),
(313, '', '', ''),
(314, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblemp`
--
ALTER TABLE `tblemp`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblemp`
--
ALTER TABLE `tblemp`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=315;--
-- Database: `MyTest`
--

-- --------------------------------------------------------

--
-- Table structure for table `EMP`
--

CREATE TABLE IF NOT EXISTS `EMP` (
  `ID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Mobile` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EMP`
--

INSERT INTO `EMP` (`ID`, `Name`, `Address`, `Mobile`) VALUES
(99, 'moin', 'surat', '9228833994'),
(100, 'anil', 'surat', '4455657888'),
(101, 'ccccc', 'dd', '5555'),
(103, 'eee', 'dd', '333333'),
(104, 'abc', 'st', '99098788'),
(105, 'abc', 'st', '99098788'),
(107, 'abc', 'nvs', '44545234'),
(108, 'tttt', 'ttttt', '4444'),
(109, 'rrr', 'rrr', '3333'),
(112, 'dddd', 'dddd', '3333'),
(113, '', '', ''),
(114, '', '', ''),
(115, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `EMP`
--
ALTER TABLE `EMP`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `EMP`
--
ALTER TABLE `EMP`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=116;--
-- Database: `Myshoppy`
--

-- --------------------------------------------------------

--
-- Table structure for table `Wishlist_master`
--

CREATE TABLE IF NOT EXISTS `Wishlist_master` (
  `wish_id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `cr_id` int(10) NOT NULL,
  `image` varchar(100) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Wishlist_master`
--

INSERT INTO `Wishlist_master` (`wish_id`, `p_id`, `cr_id`, `image`, `prod_name`, `price`) VALUES
(2, 1, 0, 'images/shirt1.jpg', 't-shirt marcos A112', 550),
(3, 2, 0, 'images/shirt2.jpg', 't-shirt marcos A112', 550);

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE IF NOT EXISTS `admin_master` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_mobile` int(10) NOT NULL,
  `admin_sex` varchar(10) NOT NULL,
  `admin_address` varchar(50) NOT NULL,
  `admin_pass` varchar(50) NOT NULL,
  `admin_conpass` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pincode` int(10) NOT NULL,
  `reg_date` date NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE IF NOT EXISTS `category_master` (
  `cat_id` int(10) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `cat_image` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `post_date` date NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`cat_id`, `cat_name`, `cat_image`, `description`, `post_date`, `status`) VALUES
(7, 'Shirts', 'icloud', 'All types of shirts', '2038-06-07', 'Y'),
(8, 'T-shirts', 'icloud', 'All types of shirts', '2038-06-07', 'Y'),
(9, 'Shoes', 'icloud', 'All types of shirts', '2038-06-07', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE IF NOT EXISTS `customer_master` (
  `cust_id` int(10) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pincode` int(10) NOT NULL,
  `confirm_pass` varchar(50) NOT NULL,
  `reg_date` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`cust_id`, `cust_name`, `mobile`, `sex`, `address`, `password`, `city`, `state`, `country`, `pincode`, `confirm_pass`, `reg_date`, `email`, `status`, `photo`) VALUES
(17, 'moin', '9228833994', '', '', 'moin123', '', '', '', 0, '', '0000-00-00', 'moinshk66@gmail.com', '', ''),
(18, 'drashti', '1234567890', '', '', 'abc123', '', '', '', 0, '', '0000-00-00', 'drashti123@gmail.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE IF NOT EXISTS `order_master` (
  `order_id` int(10) NOT NULL,
  `prod_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `cust_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `total_amount` int(10) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(10) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE IF NOT EXISTS `product_master` (
  `prod_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `admin_id` int(10) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL,
  `image` varchar(50) NOT NULL,
  `image2` varchar(50) NOT NULL,
  `size_chart` varchar(50) NOT NULL,
  `stock` int(10) NOT NULL,
  `size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `material_info` varchar(200) NOT NULL,
  `status` varchar(1) NOT NULL,
  `post_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`prod_id`, `cat_id`, `admin_id`, `prod_name`, `Description`, `price`, `image`, `image2`, `size_chart`, `stock`, `size`, `color`, `material_info`, `status`, `post_date`) VALUES
(1, 7, 0, 't-shirt marcos A112', 'Marcos collection A112 ,100% cotton making ', '550', 'images/shirt1.jpg', 'images/shirt2.jpg', '', 25, 'M,L,S', 'images/shirt2.jpg,images/shirt1.jpg', 'A1 class t-shirt , Marcos collection A112 ,100% cotton making \r\n', 'Y', '0000-00-00'),
(2, 7, 0, 't-shirt marcos A112', 'Marcos collection A112 ,100% cotton making ', '550', 'images/shirt2.jpg', 'images/shirt1.jpg', '', 25, 'L,M', 'images/shirt1.jpg', 'A1 class t-shirt', 'Y', '0000-00-00'),
(3, 8, 0, 't-shirt marcos A112', 'Marcos collection A112 ,100% cotton making ', '550', 'images/shirt1.jpg', 'images/shirt2.jpg', '', 25, 'L,M', 'images/shirt2.jpg', 'A1 class t-shirt, Marcos collection A112 ,100% cot', 'Y', '0000-00-00'),
(4, 9, 0, 'shirt macos A223', 'Macos A223 100% cotton dezire	', '600', 'images/shirt2.jpg', 'images/shirt1.jpg', '', 30, 'S,M', 'images/shirt1.jpg', 'A1 class 	shirt', 'Y', '0000-00-00'),
(5, 9, 0, 'shirt macos A223', 'Macos A223 100% cotton dezire	', '600', 'images/shirt1.jpg', 'images/shirt2.jpg', '', 30, 'M', 'images/shirt2.jpg', 'A1 class 	shirt', 'Y', '0000-00-00'),
(6, 8, 0, 'shirt abc', 'Shirt made in india			', '450', 'images/shirt1.jpg', 'images/shirt2.jpg', '', 20, 'M', 'images/shirt2.jpg', 'A1 class	', 'Y', '0000-00-00'),
(7, 7, 0, 'ggg', 'A1', '500', 'images/shirt1.jpg', 'images/shirt2.jpg', '', 10, 'L', 'images/shirt1.jpg', 'A1 class', 'Y', '0000-00-00'),
(8, 7, 0, 'shirts', 'all', '550', 'images/shirt2.jpg', 'images/shirt1.jpg', '', 21, 'M', 'images/shirt1.jpg', 'all', 'Y', '0000-00-00'),
(9, 7, 0, 'A384 shirt causual', 'A384 shirt causual fit', '600', 'images/sh.jpg', 'images/sh1.jpg', '', 10, 'M,L', 'images/sh2.jpg,images/sh3.jpg', 'A384 shirt causual with slim and good shirt', 'Y', '2017-05-27'),
(25, 0, 0, 'test', 'Test1', '425', 'images/5929301878a5b.png', '', '', 1, 'M', 'b', 'Ededeedd', 'Y', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart_master`
--

CREATE TABLE IF NOT EXISTS `shoppingcart_master` (
  `cart_id` int(10) NOT NULL,
  `prod_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `size` varchar(10) NOT NULL,
  `price` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `cust_id` int(10) NOT NULL,
  `cart_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoppingcart_master`
--

INSERT INTO `shoppingcart_master` (`cart_id`, `prod_id`, `cat_id`, `prod_name`, `image`, `size`, `price`, `qty`, `cust_id`, `cart_date`) VALUES
(99, 1, 7, 't-shirt marcos A112', 'images/shirt1.jpg', 'S', 550, 1, 0, '2017-06-08'),
(100, 9, 7, 'A384 shirt causual', 'images/sh3.jpg', 'M', 600, 1, 0, '2017-06-08'),
(101, 9, 7, 'A384 shirt causual', 'images/sh3.jpg', 'L', 600, 1, 0, '2017-06-08'),
(102, 1, 7, 't-shirt marcos A112', 'images/shirt1.jpg', 'L', 550, 1, 0, '2017-06-09'),
(103, 1, 7, 't-shirt marcos A112', '', '', 550, 1, 0, '2017-06-09'),
(104, 2, 7, 't-shirt marcos A112', 'images/shirt1.jpg', 'M', 550, 1, 0, '2017-06-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Wishlist_master`
--
ALTER TABLE `Wishlist_master`
  ADD PRIMARY KEY (`wish_id`);

--
-- Indexes for table `admin_master`
--
ALTER TABLE `admin_master`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `shoppingcart_master`
--
ALTER TABLE `shoppingcart_master`
  ADD PRIMARY KEY (`cart_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Wishlist_master`
--
ALTER TABLE `Wishlist_master`
  MODIFY `wish_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `admin_master`
--
ALTER TABLE `admin_master`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
  MODIFY `cust_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `prod_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `shoppingcart_master`
--
ALTER TABLE `shoppingcart_master`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=105;--
-- Database: `attendences`
--

-- --------------------------------------------------------

--
-- Table structure for table `que_fac`
--

CREATE TABLE IF NOT EXISTS `que_fac` (
  `que_fac_id` int(11) NOT NULL,
  `stud_enrollno` bigint(40) NOT NULL,
  `fectulty_id` int(11) NOT NULL,
  `Question` varchar(500) NOT NULL,
  `que_img` varchar(300) NOT NULL,
  `Statusid` int(11) NOT NULL,
  `readstatus` varchar(20) NOT NULL,
  `active_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `que_fac`
--

INSERT INTO `que_fac` (`que_fac_id`, `stud_enrollno`, `fectulty_id`, `Question`, `que_img`, `Statusid`, `readstatus`, `active_status`) VALUES
(1, 145043693001, 5, 'hii sir i have daut in Java', 'http://localhost/demo/Student/uploads/IMG_0003.JPG', 1, 'Read', 0),
(4, 145043693001, 5, 'hiiii', 'http://localhost/demo/Student/uploads/IMG_0003.JPG', 1, 'Read', 0),
(5, 145043693001, 5, 'hello', 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 'Read', 0),
(6, 145043693001, 3, 'hhhiii', 'http://localhost/demo/Student/uploads/IMG_0001.JPG', 1, 'Read', 0),
(7, 145043693001, 3, 'hello sir', 'http://localhost/demo/Student/uploads/IMG_0001.JPG', 1, 'Read', 0),
(8, 145043693001, 3, 'yes  tell', 'http://localhost/demo/Fectulty/uploads/IMG_0001.JPG', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_Blacklist`
--

CREATE TABLE IF NOT EXISTS `tbl_Blacklist` (
  `blacklist_id` int(11) NOT NULL,
  `stud_id` bigint(20) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `sem_id` int(11) NOT NULL,
  `Div_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_Block_user`
--

CREATE TABLE IF NOT EXISTS `tbl_Block_user` (
  `Block_user_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `stud_enrollno` bigint(20) NOT NULL,
  `Block_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assign_lecture`
--

CREATE TABLE IF NOT EXISTS `tbl_assign_lecture` (
  `lecture_id` int(11) NOT NULL,
  `sub_id` int(20) NOT NULL,
  `lecture_date` date NOT NULL,
  `lecture_time` time NOT NULL,
  `fectulty_id` int(20) NOT NULL,
  `course_id` int(20) NOT NULL,
  `branch_id` int(20) NOT NULL,
  `sem_id` int(20) NOT NULL,
  `div_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_assign_lecture`
--

INSERT INTO `tbl_assign_lecture` (`lecture_id`, `sub_id`, `lecture_date`, `lecture_time`, `fectulty_id`, `course_id`, `branch_id`, `sem_id`, `div_id`) VALUES
(6, 1, '0000-00-00', '10:00:00', 1, 1, 1, 1, 0),
(7, 1, '2016-01-02', '10:00:00', 3, 1, 1, 1, 1),
(8, 2, '0000-00-00', '02:07:00', 3, 1, 1, 1, 2),
(9, 1, '2016-02-22', '04:04:00', 3, 1, 1, 2, 1),
(10, 2, '2016-02-22', '04:08:00', 3, 1, 1, 2, 2),
(11, 1, '2016-03-14', '04:35:00', 3, 1, 1, 1, 1),
(12, 1, '2016-04-02', '11:00:00', 3, 1, 1, 1, 1),
(13, 2, '2016-04-02', '12:00:00', 4, 1, 1, 1, 1),
(14, 1, '2016-04-04', '12:00:00', 3, 1, 2, 1, 1),
(16, 1, '2016-04-05', '10:46:00', 3, 1, 2, 1, 2),
(17, 1, '2016-04-06', '12:57:00', 3, 1, 1, 1, 1),
(18, 1, '2016-04-07', '10:23:00', 3, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE IF NOT EXISTS `tbl_attendance` (
  `attendance_id` int(11) NOT NULL,
  `lecture_id` int(11) NOT NULL,
  `stud_id` bigint(12) NOT NULL,
  `fectulty_id` int(11) NOT NULL,
  `Attendance_date` date NOT NULL,
  `Attendance_time` time NOT NULL,
  `sub_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `div_name` varchar(20) NOT NULL,
  `sem_name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`attendance_id`, `lecture_id`, `stud_id`, `fectulty_id`, `Attendance_date`, `Attendance_time`, `sub_id`, `status`, `div_name`, `sem_name`) VALUES
(86, 7, 145043693001, 3, '2016-03-31', '00:00:03', 1, 'Precent', 'A', '1st'),
(87, 7, 145043693001, 3, '2016-03-31', '00:00:03', 1, 'Precent', 'A', '1st'),
(88, 7, 145043693001, 3, '2016-03-31', '00:00:03', 1, 'Absent', 'A', '1st'),
(89, 7, 145043693001, 3, '2016-03-31', '00:00:03', 1, 'Absent', 'A', '1st'),
(90, 7, 145043693005, 3, '2016-03-31', '00:00:03', 1, 'Absent', 'A', '1st'),
(91, 17, 145043693001, 4, '2016-04-06', '00:00:11', 1, 'Precent', 'A', '1st'),
(92, 17, 145043693002, 3, '2016-04-06', '00:00:11', 1, 'Precent', 'A', '1st'),
(93, 17, 145043693004, 3, '2016-04-06', '00:00:11', 1, 'Precent', 'A', '1st'),
(94, 17, 145043693005, 3, '2016-04-06', '00:00:11', 1, 'Precent', 'A', '1st'),
(95, 17, 145043693003, 4, '2016-04-06', '00:00:11', 1, 'Absent', 'A', '1st');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance_fac`
--

CREATE TABLE IF NOT EXISTS `tbl_attendance_fac` (
  `tbl_attendance_fac_id` int(11) NOT NULL,
  `fectulty_id` int(11) NOT NULL,
  `Attendance_date` date NOT NULL,
  `Attendance_time` time NOT NULL,
  `status` varchar(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendance_fac`
--

INSERT INTO `tbl_attendance_fac` (`tbl_attendance_fac_id`, `fectulty_id`, `Attendance_date`, `Attendance_time`, `status`, `course_id`, `branch_id`) VALUES
(136, 13, '2016-03-18', '03:52:43', 'Present', 2, 1),
(137, 16, '2016-03-18', '03:52:43', 'Present', 2, 1),
(138, 18, '2016-03-18', '03:52:43', 'Present', 2, 1),
(139, 14, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(140, 15, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(141, 17, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(142, 19, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(143, 20, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(144, 21, '2016-03-18', '03:52:43', 'Absent', 2, 1),
(145, 22, '2016-03-18', '03:52:43', 'Absent', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE IF NOT EXISTS `tbl_branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`branch_id`, `branch_name`) VALUES
(1, 'Computer scince'),
(2, 'Management');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(75) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`course_id`, `course_name`, `branch_id`) VALUES
(1, 'BCA', 1),
(2, 'MCA', 1),
(3, 'BBA', 2),
(4, 'MBA', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_division`
--

CREATE TABLE IF NOT EXISTS `tbl_division` (
  `div_id` int(11) NOT NULL,
  `div_name` varchar(11) NOT NULL,
  `sem_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_division`
--

INSERT INTO `tbl_division` (`div_id`, `div_name`, `sem_id`) VALUES
(1, 'A', 1),
(2, 'B', 1),
(3, 'A', 2),
(4, 'B', 2),
(5, 'A', 3),
(6, 'B', 3),
(7, 'A', 4),
(8, 'B', 4),
(9, 'A', 5),
(10, 'B', 5),
(11, 'A', 6),
(12, 'B', 6),
(13, 'A', 7),
(14, 'B', 7),
(15, 'A', 8),
(16, 'B', 8),
(17, 'A', 9),
(18, 'B', 9),
(19, 'A', 10),
(20, 'B', 10),
(21, 'A', 11),
(22, 'B', 11),
(23, 'A', 12),
(24, 'B', 12),
(25, 'A', 13),
(26, 'B', 13),
(27, 'A', 14),
(28, 'B', 14),
(29, 'A', 15),
(30, 'B', 15),
(31, 'A', 16),
(32, 'B', 16),
(33, 'A', 17),
(34, 'B', 17),
(35, 'A', 18),
(36, 'B', 18),
(37, 'A', 19),
(38, 'B', 19),
(39, 'A', 20),
(40, 'B', 20),
(41, 'A', 21),
(42, 'B', 21),
(43, 'A', 22),
(44, 'B', 22);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fectulty`
--

CREATE TABLE IF NOT EXISTS `tbl_fectulty` (
  `fectulty_id` int(11) NOT NULL,
  `fectulty_name` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `password` varchar(16) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `course_id` int(11) NOT NULL,
  `fac_image` varchar(200) NOT NULL,
  `otp` int(11) NOT NULL,
  `mobile_no` bigint(40) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fectulty`
--

INSERT INTO `tbl_fectulty` (`fectulty_id`, `fectulty_name`, `branch_id`, `user_id`, `password`, `designation`, `course_id`, `fac_image`, `otp`, `mobile_no`, `dob`, `address`) VALUES
(1, 'shiv', 1, 'Hc01', '123456', 'HOD', 0, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 886647910, '2016-03-15', '96/shiv shnaker parvti soc'),
(2, 'Chirag Patel', 1, 'pc01', '123456', 'Principal', 0, 'http://localhost/demo/Fectulty/uploads/IMG_0003.JPG', 0, 8153826525, '2015-03-16', '95/shiv shanker parvti soc'),
(3, 'Chirag Patel', 1, 'FCB01', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0001.JPG', 0, 8866479510, '1994-03-16', '96/shiv shnaker parvti soc'),
(4, 'Ankit Savaliya', 1, 'FCB02', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(5, 'Dipak BHammer', 1, 'FCB03', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(6, 'Anirudh Bhalala', 1, 'FCB04', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(7, 'Ashish Dhams', 1, 'FCB05', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(8, 'Kamal Patel', 1, 'FCB06', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(9, 'NIkung Rangholiya', 1, 'FCB07', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(10, 'Jignesh Patel', 1, 'FCB08', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(11, 'KIshan Godhani', 1, 'FCB09', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(12, 'Pratck Patel', 1, 'FCB10', '123456', 'Faculty', 1, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(13, 'Ashish Dhams', 1, 'FCM01', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(14, 'Kamal Patel', 1, 'FCM02', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(15, 'NIkung Rangholiya', 1, 'FCM03', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(16, 'Jignesh Patel', 1, 'FCM04', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(17, 'KIshan Godhani', 1, 'FCM05', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(18, 'Pratck Patel', 1, 'FCM06', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(19, 'Anirudh Bhalala', 1, 'FCM07', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(20, 'Ankit savaliya', 1, 'FCM08', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(21, 'Chirag Patel', 1, 'FCM09', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(22, 'Dipak Bhammer', 1, 'FCM10', '123456', 'Faculty', 2, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(23, 'Ashish Dhams', 2, 'FMB01', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(24, 'Kamal Patel', 2, 'FMB02', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(25, 'NIkung Rangholiya', 2, 'FMB03', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(26, 'Jignesh Patel', 2, 'FMB04', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(27, 'KIshan Godhani', 2, 'FMB05', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(28, 'Pratck Patel', 2, 'FMB06', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(29, 'Anirudh Bhalala', 2, 'FMB07', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(30, 'Ankit savaliya', 2, 'FMB08', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(31, 'Chirag Patel', 2, 'FMB09', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(32, 'Dipak Bhammer', 2, 'FMB10', '123456', 'Faculty', 3, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(33, 'Ashish Dhams', 2, 'FMM01', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(34, 'Kamal Patel', 2, 'FMM02', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(35, 'NIkung Rangholiya', 2, 'FMM03', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(36, 'Jignesh Patel', 2, 'FMM04', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(37, 'KIshan Godhani', 2, 'FMM05', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(38, 'Pratck Patel', 2, 'FMM06', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(39, 'Anirudh Bhalala', 2, 'FMM07', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(40, 'Ankit savaliya', 2, 'FMM08', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(41, 'Chirag Patel', 2, 'FMM09', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', ''),
(42, 'Dipak Bhammer', 2, 'FMM10', '123456', 'Faculty', 4, 'http://localhost/demo/Fectulty/uploads/IMG_0002.JPG', 0, 0, '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leave`
--

CREATE TABLE IF NOT EXISTS `tbl_leave` (
  `leave_id` int(20) NOT NULL,
  `faculty_id` int(20) NOT NULL,
  `date1` varchar(100) NOT NULL,
  `date2` varchar(50) NOT NULL,
  `stud_id` bigint(12) NOT NULL,
  `div_id` int(20) NOT NULL,
  `sem_id` int(20) NOT NULL,
  `reson` varchar(300) NOT NULL,
  `status` varchar(50) NOT NULL,
  `Leave_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_leave`
--

INSERT INTO `tbl_leave` (`leave_id`, `faculty_id`, `date1`, `date2`, `stud_id`, `div_id`, `sem_id`, `reson`, `status`, `Leave_status`) VALUES
(6, 3, '2015-10-04', '0000-00-00', 145043693003, 1, 1, 'nathi avu', 'acceptd', 1),
(7, 3, '2016-01-02', '0000-00-00', 145043693003, 1, 1, 'nathi Avu ja ', 'acceptd', 1),
(8, 4, '2016-03-09', '2016-03-09', 145043693003, 1, 1, 'ot fell well', 'acceptd', 1),
(9, 3, '2016-03-09', '2016-03-09', 145043693003, 1, 1, 'fdfdfdfdfd', 'acceptd', 1),
(10, 3, '2016-03-10', '2016-03-15', 145043693003, 1, 1, 'eq', 'Acceptd', 1),
(11, 5, '2016-03-16', '2016-03-16', 145043693003, 1, 1, 'ggggggggggggggggggggggggggggggggggg', 'Acceptd', 1),
(12, 5, '2016-03-16', '2016-03-16', 145043693001, 1, 1, 'athi avu', 'Rejected', 1),
(13, 10, '2016-03-06', '2016-03-06', 145043693001, 1, 1, 'dknvkvsnvdsngknvsvnsdvb', 'panding', 0),
(14, 3, '2016-04-01', '2016-04-01', 145043693003, 1, 1, 'abc', 'panding', 0),
(28, 27, '03-01-2016', '03-01-2016', 0, 0, 0, 'nathi avu', '', 0),
(31, 33, '03-01-2016', '03-06-2016', 0, 0, 0, 'bas m j', '', 0),
(36, 23, '05-07-2008', '05-07-2014', 0, 0, 0, 'wade we	', '', 0),
(38, 15, '05-07-2016', '05-12-2017', 0, 0, 0, 'nnn', '', 0),
(43, 24, '07-09-2016', '07-01-2016', 0, 0, 0, 'bbbbbbb', '', 0),
(44, 21, '07-01-2016', '07-01-2015', 0, 0, 0, 'fgstgaqwe', '', 0),
(81, 16, '10-01-2016', '10-01-2016', 0, 0, 0, 'jay mataji', '', 0),
(91, 9, '11-01-2017', '09-01-2017', 185043693004, 0, 0, 'gamde', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_semester`
--

CREATE TABLE IF NOT EXISTS `tbl_semester` (
  `sem_id` int(11) NOT NULL,
  `sem_name` varchar(20) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_semester`
--

INSERT INTO `tbl_semester` (`sem_id`, `sem_name`, `course_id`) VALUES
(1, '1st', 1),
(2, '2nd', 1),
(3, '3rd', 1),
(4, '4th', 1),
(5, '5th', 1),
(6, '6th', 1),
(7, '1st', 2),
(8, '2nd', 2),
(9, '3rd', 2),
(10, '4th', 2),
(11, '5th', 2),
(12, '6th', 2),
(13, '1st', 3),
(14, '2nd', 3),
(15, '3rd', 3),
(16, '4th', 3),
(17, '5th', 3),
(18, '6th', 3),
(19, '1st', 4),
(20, '2nd', 4),
(21, '3rd', 4),
(22, '4th', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stud`
--

CREATE TABLE IF NOT EXISTS `tbl_stud` (
  `stud_enrollno` bigint(12) NOT NULL,
  `stud_name` varchar(20) NOT NULL,
  `stud_password` varchar(16) NOT NULL,
  `stud_app_status` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `sem_id` int(11) NOT NULL,
  `Div_id` varchar(10) NOT NULL,
  `stud_img` varchar(200) NOT NULL,
  `otp` int(11) NOT NULL,
  `mobile_no` bigint(40) NOT NULL,
  `parent_mob` bigint(40) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Dob` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=195243693011 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_stud`
--

INSERT INTO `tbl_stud` (`stud_enrollno`, `stud_name`, `stud_password`, `stud_app_status`, `branch_id`, `course_id`, `sem_id`, `Div_id`, `stud_img`, `otp`, `mobile_no`, `parent_mob`, `Address`, `Dob`) VALUES
(145043693001, 'Chirag Shiv', '123456', '1', 1, 1, 1, '1', 'http://localhost/demo/Student/uploads/IMG_0001.JPG', 4880, 8866479510, 8153826525, '95/shiv shankerparvti soc', '2016-04-02'),
(145043693002, 'ANKIT Savaliya', '123456', '0', 1, 1, 1, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 2571, 8153826525, 8866479510, '95/shiv shankerparvti soc', '0000-00-00'),
(145043693003, 'Dipak Bhammer', '123456', '0', 1, 1, 1, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693004, 'Anirudh Bhalala', '123456', '0', 1, 1, 1, '1', 'http://localhost/attendences/uploads/4.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693005, 'Ashish Dhamliya', '123456', '0', 1, 1, 1, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693006, 'Kamal Patel', '123456', '0', 1, 1, 1, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693007, 'Jignesh Trivedi', '123456', '0', 1, 1, 1, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693008, 'Kishan Godhani', '123456', '0', 1, 1, 1, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693009, 'NIkunj Rangholiya', '123456', '0', 1, 1, 1, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693010, 'Pratik Patel', '123456', '0', 1, 1, 1, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145043693011, 'Chirag Patel', '123456', '0', 1, 1, 1, '2', '', 123, 0, 0, '', '0000-00-00'),
(145043693012, 'fgfgfgfgff', '123456', '', 1, 1, 1, '2', '', 0, 0, 0, '', '0000-00-00'),
(145043693013, 'Chirag Patel', '123456', '0', 1, 1, 1, '2', '', 0, 0, 0, '', '0000-00-00'),
(145043693014, 'Chirag Patel', '123456', '0', 1, 1, 1, '2', '', 0, 0, 0, '', '0000-00-00'),
(145043693015, 'Chirag Patel', '123456', '0', 1, 1, 1, '2', '', 0, 0, 0, '', '0000-00-00'),
(145143693001, 'Chirag Patel', '123456', '0', 1, 2, 7, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693002, 'Ashish Patel', '123456', '0', 1, 2, 7, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693003, 'Anirudh Patel', '123456', '0', 1, 2, 7, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693004, 'Dipak Patel', '123456', '0', 1, 2, 7, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693005, 'Nikunj Patel', '123456', '0', 1, 2, 7, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693006, 'Kamal Patel', '123456', '0', 1, 2, 7, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693007, 'Kishan Patel', '123456', '0', 1, 2, 7, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693008, 'Pratick Patel', '123456', '0', 1, 2, 7, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693009, 'Ankit Patel', '123456', '0', 1, 2, 7, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145143693010, 'Jignesh Patel', '123456', '0', 1, 2, 7, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693001, 'Chirag Patel', '123456', '0', 2, 3, 13, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 1234, 8866479510, 0, '', '0000-00-00'),
(145243693002, 'partic Patel', '123456', '0', 2, 3, 13, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693003, 'ankit Patel', '123456', '0', 2, 3, 13, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693004, 'nikunj Patel', '123456', '0', 2, 3, 13, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693005, 'dipak Patel', '123456', '0', 2, 3, 13, '1', '', 0, 0, 0, '', '0000-00-00'),
(145243693006, 'Ashis Patel', '123456', '0', 2, 3, 13, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693007, 'Anirudh Patel', '123456', '0', 2, 3, 13, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693008, 'jignesh Patel', '123456', '0', 2, 3, 13, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693009, 'kamal Patel', '123456', '0', 2, 3, 13, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145243693010, 'kishan Patel', '123456', '0', 2, 3, 13, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693001, 'chirag Patel', '123456', '0', 2, 4, 19, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693002, 'partic Patel', '123456', '0', 2, 4, 19, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693003, 'ankit Patel', '123456', '0', 2, 4, 19, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693004, 'nikunj Patel', '123456', '0', 2, 4, 19, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693005, 'dipak Patel', '123456', '0', 2, 4, 19, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693006, 'Ashis Patel', '123456', '0', 2, 4, 19, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693007, 'Anirudh Patel', '123456', '0', 2, 4, 19, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693008, 'jignesh Patel', '123456', '0', 2, 4, 19, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693009, 'kamal Patel', '123456', '0', 2, 4, 19, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(145343693010, 'kishan Patel', '123456', '0', 2, 4, 19, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693001, 'Chirag Patel', '123456', '0', 1, 1, 2, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693002, 'ANKIT savaliay', '123456', '0', 1, 1, 2, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693003, 'Ashish Dhamliya', '123456', '0', 1, 1, 2, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693004, 'Kamal Patel', '123456', '0', 1, 1, 2, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693005, 'Pratik Patel', '123456', '0', 1, 1, 2, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693006, 'Jignesh Trivedi', '123456', '0', 1, 1, 2, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693007, 'kishan godhani', '123456', '0', 1, 1, 2, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693008, 'Nikunj Rangoliya', '123456', '0', 1, 1, 2, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693009, 'Dipak Bhammer Trived', '123456', '0', 1, 1, 2, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155043693010, 'Bhalal Anirudh', '123456', '0', 1, 1, 2, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693001, 'Chirag Patel', '123456', '0', 1, 2, 8, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693002, 'Ankit Patel', '123456', '0', 1, 2, 8, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693003, 'DIpak Patel', '123456', '0', 1, 2, 8, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693004, 'Nikunj Patel', '123456', '0', 1, 2, 8, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693005, 'Anirudh Patel', '123456', '0', 1, 2, 8, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693006, 'Ashish Patel', '123456', '0', 1, 2, 8, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693007, 'Jignesh Patel', '123456', '0', 1, 2, 8, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693008, 'Pratick Patel', '123456', '0', 1, 2, 8, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693009, 'KIshan Patel', '123456', '0', 1, 2, 8, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155143693010, 'Kamal Patel', '123456', '0', 1, 2, 8, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693001, 'chirag Patel', '123456', '0', 2, 3, 14, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693002, 'partic Patel', '123456', '0', 2, 3, 14, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693003, 'ankit Patel', '123456', '0', 2, 3, 14, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693004, 'nikunj Patel', '123456', '0', 2, 3, 14, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693005, 'dipak Patel', '123456', '0', 2, 3, 14, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693006, 'Ashis Patel', '123456', '0', 2, 3, 14, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693007, 'Anirudh Patel', '123456', '0', 2, 3, 14, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693008, 'jignesh Patel', '123456', '0', 2, 3, 14, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693009, 'kamal Patel', '123456', '0', 2, 3, 14, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155243693010, 'kishan Patel', '123456', '0', 2, 3, 14, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693001, 'chirag Patel', '123456', '0', 2, 4, 20, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693002, 'partic Patel', '123456', '0', 2, 4, 20, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693003, 'ankit Patel', '123456', '0', 2, 4, 20, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693004, 'nikunj Patel', '123456', '0', 2, 4, 20, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693005, 'dipak Patel', '123456', '0', 2, 4, 20, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693006, 'Ashis Patel', '123456', '0', 2, 4, 20, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693007, 'Anirudh Patel', '123456', '0', 2, 4, 20, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693008, 'jignesh Patel', '123456', '0', 2, 4, 20, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693009, 'kamal Patel', '123456', '0', 2, 4, 20, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(155343693010, 'kishan Patel', '123456', '0', 2, 4, 20, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693001, 'Chirag Patel', '123456', '0', 1, 1, 3, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693002, 'Dipak BHammer', '123456', '0', 1, 1, 3, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693003, 'Anirudh Bhalala', '123456', '0', 1, 1, 3, '1', 'http://localhost/attendences/uploads/3.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693004, 'Ashish Dhamliya', '123456', '0', 1, 1, 3, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693005, 'Ankit Savaliya', '123456', '0', 1, 1, 3, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693006, 'Kamal Patel', '123456', '0', 1, 1, 3, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693007, 'Jignesh Trivedi', '123456', '0', 1, 1, 3, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693008, 'Paratick Patel', '123456', '0', 1, 1, 3, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693009, 'KIshan Godhani', '123456', '0', 1, 1, 3, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165043693010, 'Nikunj Rangholiya', '123456', '0', 1, 1, 3, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693001, 'Chirag Patel', '123456', '0', 1, 2, 9, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693002, 'Ankit Patel', '123456', '0', 1, 2, 9, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693003, 'Dipak Patel', '123456', '0', 1, 2, 9, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693004, 'Nikunj Patel', '123456', '0', 1, 2, 9, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693005, 'Anirudh Patel', '123456', '0', 1, 2, 9, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693006, 'Ashish Patel', '123456', '0', 1, 2, 9, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693007, 'JIgnesh Patel', '123456', '0', 1, 2, 9, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693008, 'Pratick Patel', '123456', '0', 1, 2, 9, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693009, 'KIshan Patel', '123456', '0', 1, 2, 9, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165143693010, 'Kamal Patel', '123456', '0', 1, 2, 9, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693001, 'chirag Patel', '123456', '0', 2, 3, 15, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693002, 'partic Patel', '123456', '0', 2, 3, 15, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693003, 'ankit Patel', '123456', '0', 2, 3, 15, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693004, 'nikunj Patel', '123456', '0', 2, 3, 15, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693005, 'dipak Patel', '123456', '0', 2, 3, 15, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693006, 'Ashis Patel', '123456', '0', 2, 3, 15, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693007, 'Anirudh Patel', '123456', '0', 2, 3, 15, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693008, 'jignesh Patel', '123456', '0', 2, 3, 15, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693009, 'kamal Patel', '123456', '0', 2, 3, 15, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165243693010, 'kishan Patel', '123456', '0', 2, 3, 15, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693001, 'chirag Patel', '123456', '0', 2, 4, 21, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693002, 'partic Patel', '123456', '0', 2, 4, 21, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693003, 'ankit Patel', '123456', '0', 2, 4, 21, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693004, 'nikunj Patel', '123456', '0', 2, 4, 21, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693005, 'dipak Patel', '123456', '0', 2, 4, 21, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693006, 'Ashis Patel', '123456', '0', 2, 4, 21, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693007, 'Anirudh Patel', '123456', '0', 2, 4, 21, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693008, 'jignesh Patel', '123456', '0', 2, 4, 21, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693009, 'kamal Patel', '123456', '0', 2, 4, 21, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(165343693010, 'kishan Patel', '123456', '0', 2, 4, 21, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693001, 'Chirag Patel', '123456', '0', 1, 1, 4, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693002, 'Ankit Savaliya', '123456', '0', 1, 1, 4, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693003, 'Ashish Dhams', '123456', '0', 1, 1, 4, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693004, 'Anirudh Bhalala', '123456', '0', 1, 1, 4, '1', 'http://localhost/attendences/uploads/2.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693005, 'Dipak Bhammer', '123456', '0', 1, 1, 4, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693006, 'Jigs Trivedi', '123456', '0', 1, 1, 4, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693007, 'Pratick Patel', '123456', '0', 1, 1, 4, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693008, 'Patick Patel', '123456', '0', 1, 1, 4, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693009, 'Nikunj Rangholiya', '123456', '0', 1, 1, 4, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175043693010, 'KIshan Gohani', '123456', '0', 1, 1, 4, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693001, 'Chirag Patel', '123456', '0', 1, 2, 10, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693002, 'Ankit Patel', '123456', '0', 1, 2, 10, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693003, 'Ashish Patel', '123456', '0', 1, 2, 10, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693004, 'Anirudh Patel', '123456', '0', 1, 2, 10, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693005, 'Dipak Patel', '123456', '0', 1, 2, 10, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693006, 'Nikunj Patel', '123456', '0', 1, 2, 10, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693007, 'Kamal Patel', '123456', '0', 1, 2, 10, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693008, 'Kishan Patel', '123456', '0', 1, 2, 10, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693009, 'JIgnesh Patel', '123456', '0', 1, 2, 10, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175143693010, 'Pratck Patel', '123456', '0', 1, 2, 10, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693001, 'chirag Patel', '123456', '0', 2, 3, 16, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693002, 'partic Patel', '123456', '0', 2, 3, 16, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693003, 'ankit Patel', '123456', '0', 2, 3, 16, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693004, 'nikunj Patel', '123456', '0', 2, 3, 16, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693005, 'dipak Patel', '123456', '0', 2, 3, 16, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693006, 'Ashis Patel', '123456', '0', 2, 3, 16, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693007, 'Anirudh Patel', '123456', '0', 2, 3, 16, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693008, 'jignesh Patel', '123456', '0', 2, 3, 16, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693009, 'kamal Patel', '123456', '0', 2, 3, 16, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175243693010, 'kishan Patel', '123456', '0', 2, 3, 16, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693001, 'chirag Patel', '123456', '0', 2, 4, 22, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693002, 'partic Patel', '123456', '0', 2, 4, 22, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693003, 'ankit Patel', '123456', '0', 2, 4, 22, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693004, 'nikunj Patel', '123456', '0', 2, 4, 22, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693005, 'dipak Patel', '123456', '0', 2, 4, 22, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693006, 'Ashis Patel', '123456', '0', 2, 4, 22, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693007, 'Anirudh Patel', '123456', '0', 2, 4, 22, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693008, 'jignesh Patel', '123456', '0', 2, 4, 22, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693009, 'kamal Patel', '123456', '0', 2, 4, 22, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(175343693010, 'kishan Patel', '123456', '0', 2, 4, 22, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693001, 'Chirag Patel', '123456', '0', 1, 1, 5, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693002, 'Pratick Patel', '123456', '0', 1, 1, 5, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693003, 'kamal Patel', '123456', '0', 1, 1, 5, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693004, 'Ahish Patel', '123456', '0', 1, 1, 5, '1', 'http://localhost/attendences/uploads/3.JPG', 0, 8141413471, 7507060807, 'surat', '1994-11-28'),
(185043693005, 'Anirudh Patel', '123456', '0', 1, 1, 5, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693006, 'Kishan Patel', '123456', '0', 1, 1, 5, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693007, 'Nikunj Patel', '123456', '0', 1, 1, 5, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693008, 'Dipak Patel', '123456', '0', 1, 1, 5, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693009, 'ankit Patel', '123456', '0', 1, 1, 5, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185043693010, 'anirudh Patel', '123456', '0', 1, 1, 5, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693001, 'Chirag Patel', '123456', '0', 1, 2, 11, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693002, 'Ankit Patel', '123456', '0', 1, 2, 11, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693003, 'Ashish Patel', '123456', '0', 1, 2, 11, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693004, 'Anirudh Patel', '123456', '0', 1, 2, 11, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693005, 'Dipak Patel', '123456', '0', 1, 2, 11, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693006, 'Nikunj Patel', '123456', '0', 1, 2, 11, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693007, 'Kamal Patel', '123456', '0', 1, 2, 11, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693008, 'Kishan Patel', '123456', '0', 1, 2, 11, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693009, 'JIgnesh Patel', '123456', '0', 1, 2, 11, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185143693010, 'Pratck Patel', '123456', '0', 1, 2, 11, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693001, 'chirag Patel', '123456', '0', 2, 3, 17, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693002, 'partic Patel', '123456', '0', 2, 3, 17, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693003, 'ankit Patel', '123456', '0', 2, 3, 17, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693004, 'nikunj Patel', '123456', '0', 2, 3, 17, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693005, 'dipak Patel', '123456', '0', 2, 3, 17, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693006, 'Ashis Patel', '123456', '0', 2, 3, 17, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693007, 'Anirudh Patel', '123456', '0', 2, 3, 17, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693008, 'jignesh Patel', '123456', '0', 2, 3, 17, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693009, 'kamal Patel', '123456', '0', 2, 3, 17, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(185243693010, 'kishan Patel', '123456', '0', 2, 3, 17, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693001, 'pinrag Patel', '123456', '0', 1, 1, 6, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693002, 'Ankit Savaliya', '123456', '0', 1, 1, 6, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693003, 'Anirudh BHalala', '123456', '0', 1, 1, 6, '1', 'http://localhost/attendences/uploads/5.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693004, 'NIkunj Rangholiya', '123456', '0', 1, 1, 6, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693005, 'Paratick Patel', '123456', '0', 1, 1, 6, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693006, 'Kamal Patel', '123456', '0', 1, 1, 6, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693007, 'KIshan Patel', '123456', '0', 1, 1, 6, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693008, 'Jignesh Patel', '123456', '0', 1, 1, 6, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693009, 'Dipka Ahir', '123456', '0', 1, 1, 6, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195043693010, 'Ashis Dhamo', '123456', '0', 1, 1, 6, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693001, 'Chirag Patel', '123456', '0', 1, 2, 12, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693002, 'Ankit Patel', '123456', '0', 1, 2, 12, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693003, 'Ashish Patel', '123456', '0', 1, 2, 12, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693004, 'Anirudh Patel', '123456', '0', 1, 2, 12, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693005, 'Dipak Patel', '123456', '0', 1, 2, 12, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693006, 'Nikunj Patel', '123456', '0', 1, 2, 12, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693007, 'Kamal Patel', '123456', '0', 1, 2, 12, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693008, 'Kishan Patel', '123456', '0', 1, 2, 12, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693009, 'JIgnesh Patel', '123456', '0', 1, 2, 12, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195143693010, 'Pratck Patel', '123456', '0', 1, 2, 12, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693001, 'chirag Patel', '123456', '0', 2, 3, 18, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693002, 'partic Patel', '123456', '0', 2, 3, 18, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693003, 'ankit Patel', '123456', '0', 2, 3, 18, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693004, 'nikunj Patel', '123456', '0', 2, 3, 18, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693005, 'dipak Patel', '123456', '0', 2, 3, 18, '1', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693006, 'Ashis Patel', '123456', '0', 2, 3, 18, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693007, 'Anirudh Patel', '123456', '0', 2, 3, 18, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693008, 'jignesh Patel', '123456', '0', 2, 3, 18, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693009, 'kamal Patel', '123456', '0', 2, 3, 18, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 0, 0, 0, '', '0000-00-00'),
(195243693010, 'kishan Patel', '123456', '0', 2, 3, 18, '2', 'http://localhost/demo/Student/uploads/IMG_0002.JPG', 1234, 8866479510, 0, '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE IF NOT EXISTS `tbl_subject` (
  `sub_id` int(11) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `sem_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`sub_id`, `sub_name`, `sem_id`) VALUES
(1, '101 - Communication Skills', 1),
(2, '102 - Mathematics - I', 1),
(3, '103 - Introduction to Computers', 1),
(4, '105_CBCS - Office Automation', 1),
(5, '104_CBCS - Computer Programming & Programming Methodology (C Lang)', 1),
(6, '201 - Organization Structure and Behaviour', 2),
(7, '202 - Computerized Financial Accounting', 2),
(8, '203 - Introduction to Operating System', 2),
(9, '204_Old - Programming Language - I', 2),
(10, '205 - Database Management Systems', 2),
(11, '206 - Practicals(Based on 201,204 and 205)', 2),
(12, '204_CBCS - Advanced C Programming', 2),
(13, '301_CBCS - STATISTICAL METHODS', 3),
(14, '302_CBCS - SOFTWARE ENGINEERING - I', 3),
(15, '303_CBCS - RELATIONAL DATABASE MANAGEMENT SYSTEM', 3),
(16, '304_CBCS - DATA STRUCTURES', 3),
(17, '305_CBCS - OBJECT ORIENTED PROGRAMMING', 3),
(18, '401_CBCS - INFORMATION SYSTEMS', 4),
(19, '402_CBCS - SOFTWARE ENGINEERING - II', 4),
(20, '403_CBCS - JAVA PROGRAMMING LANGUAGE', 4),
(21, '404_CBCS - .NET PROGRAMMING', 4),
(22, '405_CBCS - WEB DESIGNING', 4),
(23, '406_CBCS - Practical', 4),
(24, '504 - Operating Systems – II', 5),
(25, '505 - ASP.NET', 5),
(26, '501 - PHP MYSQL', 5),
(27, '502 - UNIX & SHELL PROG RAMMING', 5),
(28, '503_CBCS - Network Technologies', 5),
(29, '601 - Computer Graphics', 6),
(30, '602 - E-Commerce & Cyber Security', 6),
(31, '2610001 -Fundamentals of Programming (FOP)', 7),
(32, '2610002 - Enterprise Resource Planning (ERP)', 7),
(33, '2610003 - Discrete Mathematics for Computer Science (DMCS)', 7),
(34, '2610004 - Fundamentals of Computer Organization (FCO)', 7),
(35, '2610005 - Communications Skills (CS)', 7),
(36, '2610006 - Programming Skills-I (PS-I-FOP)', 7),
(37, '2610007 - Software Project in C (SP-C)', 7),
(38, '2620001 - Data Structures (DS)', 8),
(39, '2620002 - Object-Oriented Programming Concepts & Programming(OOCP)', 8),
(40, '2620003- Database Management System (DBMS)', 8),
(41, '2620004 - Computer-Oriented Numerical Methods (CONM)', 8),
(42, '2620005 - Programming Skills-II (PS-OOCP)', 8),
(43, '2620006 - Software Lab (DBMS: SQL & Pl/SQL)', 8),
(44, '2620007 - Software Project in C++ (SP-CPP)', 8),
(45, '630001 - Structured & Object Oriented Analysis & Design Methodology (SOOADM)', 9),
(46, '630002 - Fundamentals of Java Programming(Java)', 9),
(47, '630003 - Statistical Methods (SM)', 9),
(48, '630004 - Operating Systems (OS)', 9),
(49, '630005 - System Software (SS)', 9),
(50, '630006 - Programming Skills-IV (Java)', 9),
(51, '630007 - Programming Skills-V (OS)', 9),
(52, '640001 - Fundamentals of Networking (FON)', 10),
(53, '640002 - Web Technology & Application Development(WTAD)', 10),
(54, '640003 - Operations Research (OR)', 10),
(55, '640004 - Management Information System (MIS)', 10),
(56, 'lective-I', 10),
(57, '640011- Programming Skills VI (FON)', 10),
(58, '640012 - Programming Skills VII (WTAD)', 10),
(59, '650001 - Software Engineering (SE)', 11),
(60, '650002- Network Security (NS)', 11),
(61, '650003 -Mobile Computing (MC)?', 11),
(62, 'Elective-II', 11),
(63, 'Elective-III', 11),
(64, '650017 - Software Lab in Mobile Computing (SL-MC)', 11),
(65, '650018 - Dissertation (DSRT) & Project Defination', 11),
(66, '660001 Project', 12),
(67, 'Elements of Economics', 13),
(68, 'Principles of Management', 13),
(69, 'Communication Skills- 1', 13),
(70, 'Computer Applications', 13),
(71, 'Managerial Economics', 14),
(72, 'Communication Skills- II', 14),
(73, 'Financial Accounting', 14),
(74, 'Quantitative Methods- I ', 14),
(75, 'Marketing Management', 15),
(76, 'Behavioral Science ', 15),
(77, 'Management Accounting ', 15),
(78, 'Quantitative Methods-II \n                                    ( Statistics Oriented) ', 15),
(79, 'Computer Applications-II', 16),
(80, 'Financial Management', 16),
(81, 'Human Resources Management', 16),
(82, 'Production Management', 16),
(83, 'Computer Application – III ', 17),
(84, 'Entrepreneurship Development & Small Business  \nManagement ', 17),
(85, 'Research Methodology (Survey Methods) ', 17),
(86, 'Business Environment', 17),
(87, 'Elements of Strategic Management', 18),
(88, 'Project ', 18),
(89, '2810001	Accounting for Managers (AFM)', 19),
(90, '2810002	Economics for Managers (EFM) ', 19),
(91, '2810003	Managerial Communication (MC)', 19),
(92, '2810004	Organizational Behaviour (OB)', 19),
(93, '2810005	Principles of Management (PM)', 19),
(94, '2810006	Research Methodology (RM)', 19),
(95, '2810007	Quantitative Analysis ? I (QA-I)', 19),
(96, '2820001	Cost and Management Accounting (CMA)', 20),
(97, '2820002	Management Information System (MIS) ', 20),
(98, '2820003	Financial Management (FM)', 20),
(99, '2820004	Human Resource Management (HRM)', 20),
(100, '2820005	Marketing Management (MM)', 20),
(101, '2820006	Production and Operations Management (POM) ', 20),
(102, '2820007	Quantitative Analysis ? II (QA-II) ', 20),
(103, '2830001	Strategic Management (SM)', 21),
(104, '2830002	Legal Aspects of Business (LAB)', 21),
(105, '2830003	Global / Country Study Report (GCR)', 21),
(106, '2830006	International Business (IB)', 21),
(107, '2830007	New Enterprise and Innovation Management (NE&IM)', 21),
(108, '2840003	Business Ethics and Corporate Governance (BE & CG)', 22),
(109, '2840004	Enterprise Resource Planning (ERP)', 22),
(110, '2840005	Supply Chain Management (SCM)', 22),
(111, '2840006	Project Management (PM)', 22),
(112, '2840007	Management Control System (MCS)', 22);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `que_fac`
--
ALTER TABLE `que_fac`
  ADD PRIMARY KEY (`que_fac_id`);

--
-- Indexes for table `tbl_Blacklist`
--
ALTER TABLE `tbl_Blacklist`
  ADD PRIMARY KEY (`blacklist_id`),
  ADD KEY `stud_id` (`stud_id`,`faculty_id`);

--
-- Indexes for table `tbl_Block_user`
--
ALTER TABLE `tbl_Block_user`
  ADD PRIMARY KEY (`Block_user_id`);

--
-- Indexes for table `tbl_assign_lecture`
--
ALTER TABLE `tbl_assign_lecture`
  ADD PRIMARY KEY (`lecture_id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `tbl_attendance_fac`
--
ALTER TABLE `tbl_attendance_fac`
  ADD PRIMARY KEY (`tbl_attendance_fac_id`);

--
-- Indexes for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `tbl_division`
--
ALTER TABLE `tbl_division`
  ADD PRIMARY KEY (`div_id`);

--
-- Indexes for table `tbl_fectulty`
--
ALTER TABLE `tbl_fectulty`
  ADD PRIMARY KEY (`fectulty_id`);

--
-- Indexes for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `tbl_semester`
--
ALTER TABLE `tbl_semester`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `tbl_stud`
--
ALTER TABLE `tbl_stud`
  ADD PRIMARY KEY (`stud_enrollno`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `que_fac`
--
ALTER TABLE `que_fac`
  MODIFY `que_fac_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_Blacklist`
--
ALTER TABLE `tbl_Blacklist`
  MODIFY `blacklist_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_Block_user`
--
ALTER TABLE `tbl_Block_user`
  MODIFY `Block_user_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_assign_lecture`
--
ALTER TABLE `tbl_assign_lecture`
  MODIFY `lecture_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=96;
--
-- AUTO_INCREMENT for table `tbl_attendance_fac`
--
ALTER TABLE `tbl_attendance_fac`
  MODIFY `tbl_attendance_fac_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=146;
--
-- AUTO_INCREMENT for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_division`
--
ALTER TABLE `tbl_division`
  MODIFY `div_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `tbl_fectulty`
--
ALTER TABLE `tbl_fectulty`
  MODIFY `fectulty_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  MODIFY `leave_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `tbl_semester`
--
ALTER TABLE `tbl_semester`
  MODIFY `sem_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_stud`
--
ALTER TABLE `tbl_stud`
  MODIFY `stud_enrollno` bigint(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=195243693011;
--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=113;--
-- Database: `db_cab`
--

-- --------------------------------------------------------

--
-- Table structure for table `AddCabDetail`
--

CREATE TABLE IF NOT EXISTS `AddCabDetail` (
  `Cab_Id` int(11) NOT NULL,
  `CabType_Id` int(11) NOT NULL,
  `makeModel` varchar(250) NOT NULL,
  `ServiceProvider_Id` int(11) NOT NULL,
  `Total_Capacity` int(11) NOT NULL,
  `fuelType` varchar(80) NOT NULL,
  `Rate_Per_Km` float NOT NULL,
  `registrationNo` varchar(80) NOT NULL,
  `Status` varchar(40) NOT NULL,
  `Image` varchar(1000) NOT NULL,
  `Description` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AddCabDetail`
--

INSERT INTO `AddCabDetail` (`Cab_Id`, `CabType_Id`, `makeModel`, `ServiceProvider_Id`, `Total_Capacity`, `fuelType`, `Rate_Per_Km`, `registrationNo`, `Status`, `Image`, `Description`) VALUES
(6, 0, 'honda civic', 21, 4, 'CNG', 5.5, 'GJ05 BH 1234', '', 'UPLOAD_DIR58771c19bb2b9.png', 'New'),
(7, 0, 'Maruti Omni', 22, 7, 'CNG', 4, 'GJ15 KL 1234', '', 'UPLOAD_DIR587747e0c13c0.png', '2 yrs old'),
(8, 0, '', 0, 0, '', 0, '', '', 'UPLOAD_DIR587dd140d1479.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `BookingTable`
--

CREATE TABLE IF NOT EXISTS `BookingTable` (
  `Booking_Id` int(11) NOT NULL,
  `User_Id` int(11) NOT NULL,
  `Cab_Id` int(11) NOT NULL,
  `From_Address` varchar(40) NOT NULL,
  `To_Address` varchar(40) NOT NULL,
  `Total_Km` float NOT NULL,
  `Total_Amount` float NOT NULL,
  `Status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CabRegistration`
--

CREATE TABLE IF NOT EXISTS `CabRegistration` (
  `ServiceProvider_Id` int(11) NOT NULL,
  `ServiceProvider_Name` varchar(40) NOT NULL,
  `ServiceProvider_Email` varchar(40) NOT NULL,
  `ServiceProvider_Mo_Number` varchar(10) NOT NULL,
  `ServiceProvider_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CabType`
--

CREATE TABLE IF NOT EXISTS `CabType` (
  `CabType_Id` int(11) NOT NULL,
  `CabType_Name` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CabType`
--

INSERT INTO `CabType` (`CabType_Id`, `CabType_Name`) VALUES
(1, 'Hatchback'),
(2, 'Sedan'),
(3, 'Van'),
(4, 'SUV'),
(5, 'MPV');

-- --------------------------------------------------------

--
-- Table structure for table `ContactUs`
--

CREATE TABLE IF NOT EXISTS `ContactUs` (
  `Contact_Id` int(11) NOT NULL,
  `Contact_Name` varchar(40) NOT NULL,
  `Mo_Number` varchar(40) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Description` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE IF NOT EXISTS `Payment` (
  `Payment_Id` int(11) NOT NULL,
  `Booking_Id` int(11) NOT NULL,
  `Payment_Type` varchar(40) NOT NULL,
  `Total_Amount` float NOT NULL,
  `Service_Tax` float NOT NULL,
  `Status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Review`
--

CREATE TABLE IF NOT EXISTS `Review` (
  `Review_Id` int(11) NOT NULL,
  `Prview_Description` varchar(150) NOT NULL,
  `Number_Of_Rating` int(11) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `UserRegistration`
--

CREATE TABLE IF NOT EXISTS `UserRegistration` (
  `User_Id` int(11) NOT NULL,
  `User_Name` varchar(40) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `Mo_Number` varchar(40) NOT NULL,
  `Email_Id` varchar(40) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Status` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserRegistration`
--

INSERT INTO `UserRegistration` (`User_Id`, `User_Name`, `Address`, `Mo_Number`, `Email_Id`, `Password`, `Status`) VALUES
(1, 'UserOne', '', '1111111111', 'user1@gmail.com', 'user1123', ''),
(2, 'Bhavesh', 'pandesara', '8866995959', 'j@gmail.com', 'B#@ve$#108', '');

-- --------------------------------------------------------

--
-- Table structure for table `serviceProvider`
--

CREATE TABLE IF NOT EXISTS `serviceProvider` (
  `user_id` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(80) NOT NULL,
  `DOB` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `serviceProvider`
--

INSERT INTO `serviceProvider` (`user_id`, `image`, `name`, `email`, `mobile`, `address`, `gender`, `password`, `DOB`) VALUES
(21, 'images/58774d065eafa.png', 'DriverOne', 'driver1@gmail.com', '1111111111', 'ahmedabad', 'Male', 'driver1123', '12-01-1972'),
(22, 'images/58771af15985a.png', 'DriverTwo', 'driver2@gmail.com', '2222222222', 'valsad', 'Female', 'driver2123', '29-08-1985'),
(23, 'images/58771b570f60a.png', 'DriverThree', 'driver3@gmail.com', '3333333333', 'Ahmedabad', 'Male', 'driver3123', '27-09-1962'),
(25, 'images/587de7b0cd764.png', 'DriverFive', 'driver5@gmail.com', '5555555555', 'surat', 'Female', 'driver5123', '09-01-1986');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AddCabDetail`
--
ALTER TABLE `AddCabDetail`
  ADD PRIMARY KEY (`Cab_Id`);

--
-- Indexes for table `BookingTable`
--
ALTER TABLE `BookingTable`
  ADD PRIMARY KEY (`Booking_Id`);

--
-- Indexes for table `CabRegistration`
--
ALTER TABLE `CabRegistration`
  ADD PRIMARY KEY (`ServiceProvider_Id`);

--
-- Indexes for table `CabType`
--
ALTER TABLE `CabType`
  ADD PRIMARY KEY (`CabType_Id`);

--
-- Indexes for table `ContactUs`
--
ALTER TABLE `ContactUs`
  ADD PRIMARY KEY (`Contact_Id`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD PRIMARY KEY (`Payment_Id`);

--
-- Indexes for table `Review`
--
ALTER TABLE `Review`
  ADD PRIMARY KEY (`Review_Id`);

--
-- Indexes for table `UserRegistration`
--
ALTER TABLE `UserRegistration`
  ADD PRIMARY KEY (`User_Id`);

--
-- Indexes for table `serviceProvider`
--
ALTER TABLE `serviceProvider`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AddCabDetail`
--
ALTER TABLE `AddCabDetail`
  MODIFY `Cab_Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `BookingTable`
--
ALTER TABLE `BookingTable`
  MODIFY `Booking_Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CabRegistration`
--
ALTER TABLE `CabRegistration`
  MODIFY `ServiceProvider_Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CabType`
--
ALTER TABLE `CabType`
  MODIFY `CabType_Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ContactUs`
--
ALTER TABLE `ContactUs`
  MODIFY `Contact_Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Payment`
--
ALTER TABLE `Payment`
  MODIFY `Payment_Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Review`
--
ALTER TABLE `Review`
  MODIFY `Review_Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `UserRegistration`
--
ALTER TABLE `UserRegistration`
  MODIFY `User_Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `serviceProvider`
--
ALTER TABLE `serviceProvider`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;--
-- Database: `db_online_resturant`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE IF NOT EXISTS `category_table` (
  `cat_id` varchar(100) NOT NULL,
  `cat_name` varchar(20) NOT NULL,
  `cat_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`cat_id`, `cat_name`, `cat_type`) VALUES
('cat_pro_aniversary_004', 'aniversary', 'booking'),
('cat_pro_birthday_001', 'birthday', 'booking'),
('cat_pro_cold_drinks_006', 'cold_drinks', 'menu'),
('cat_pro_dinner_003', 'dinner', 'special'),
('cat_pro_farewell_003', 'farewell', 'booking'),
('cat_pro_fastfod_001', 'fastfood', 'menu'),
('cat_pro_gujarati_thali_004', 'gujarati_thali', 'menu'),
('cat_pro_ice_cream_007', 'ice-cream', 'menu'),
('cat_pro_lunch_002\r\n', 'lunch', 'special'),
('cat_pro_merriage_002', 'merriage', 'booking'),
('cat_pro_punjabi_thali_005', 'punjabi_thali', 'menu');

-- --------------------------------------------------------

--
-- Table structure for table `company_registration`
--

CREATE TABLE IF NOT EXISTS `company_registration` (
  `company_id` varchar(100) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `company_address` varchar(100) NOT NULL,
  `company_email` varchar(100) NOT NULL,
  `company_mo_number` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `company_logo` varchar(1000) NOT NULL,
  `status` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_registration`
--

INSERT INTO `company_registration` (`company_id`, `company_name`, `company_address`, `company_email`, `company_mo_number`, `password`, `company_logo`, `status`) VALUES
('00001', 'xyz', 'surat', 'abc@gmail.com', '7405577589', 'password', 'company_images/587c85ac3683b.png', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE IF NOT EXISTS `order_table` (
  `order_id` varchar(100) NOT NULL,
  `product_id` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `o_quantity` int(11) NOT NULL,
  `total_amount` float NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `status` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `total_amount` float NOT NULL,
  `total_no_product` int(11) NOT NULL,
  `payment_method` varchar(500) NOT NULL,
  `service_text` float NOT NULL,
  `payment_status` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_return`
--

CREATE TABLE IF NOT EXISTS `product_return` (
  `return_id` varchar(100) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `return_reason` varchar(1000) NOT NULL,
  `approve_by` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_table`
--

CREATE TABLE IF NOT EXISTS `product_table` (
  `product_id` varchar(100) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_prize` float NOT NULL,
  `product_categoryid` varchar(100) NOT NULL,
  `subcat_id` varchar(100) NOT NULL,
  `product_description` varchar(600) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(600) NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_table`
--

INSERT INTO `product_table` (`product_id`, `product_name`, `product_prize`, `product_categoryid`, `subcat_id`, `product_description`, `quantity`, `status`, `company_id`) VALUES
('pro_fast_001', 'pizza', 150, 'cat_pro_fastfod_001', 'sub_cat_pro_fastfood_001', 'pizz with the extra cheez and helthy.if u are in discount then get discount coupen.', 1, 'testy', 1),
('pro_menu', 'fureji', 50, 'cat_pro_fastfod_001', 'sub_cat_pro_fastfood_002', 'its a nonveg item', 1, 'amaze', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rating_table`
--

CREATE TABLE IF NOT EXISTS `rating_table` (
  `rating_id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `number_of_rate` int(11) NOT NULL,
  `rate_description` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_category_table`
--

CREATE TABLE IF NOT EXISTS `sub_category_table` (
  `subcat_id` varchar(100) NOT NULL,
  `subcat_name` varchar(30) NOT NULL,
  `price` double NOT NULL,
  `sub_cat_image` varchar(10000) NOT NULL,
  `cat_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category_table`
--

INSERT INTO `sub_category_table` (`subcat_id`, `subcat_name`, `price`, `sub_cat_image`, `cat_id`) VALUES
('sub_cat_pro_cold_drinks_001', 'cold-coco', 60, 'product_image/cold_coco.jpeg', 'cat_pro_cold_drinks_006'),
('sub_cat_pro_cold_drinks_002', 'Pepsi', 40.5, 'product_image/Soft-drink.jpeg', 'cat_pro_cold_drinks_006'),
('sub_cat_pro_dinner_001', 'veg_dinner', 280.65, 'product_image/dinner_2.jpeg', 'cat_pro_dinner_003'),
('sub_cat_pro_dinner_002', 'nonveg_dinner', 485.41, 'product_image/dinner_1.jpeg', 'cat_pro_dinner_003'),
('sub_cat_pro_fastfood_001', 'pizza', 250, 'product_image/pizza.jpeg', 'cat_pro_fastfod_001'),
('sub_cat_pro_fastfood_002', 'grill_sandwich', 180, 'product_image/grill_sandwich.jpeg', 'cat_pro_fastfod_001'),
('suB_cat_pro_fastfood_003', 'burger', 65.25, 'product_image/burger.jpeg', 'cat_pro_fastfod_001'),
('sub_cat_pro_gujarati_thali_001', 'Full_Thali', 243.21, 'product_image/full_dish.jpeg', 'cat_pro_gujarati_thali_004'),
('sub_cat_pro_gujarati_thali_002', 'Jumbo_Thali', 607.54, 'product_image/jumbo_dish.jpeg', 'cat_pro_gujarati_thali_004'),
('sub_cat_pro_ice_cream_001', 'Combo-pack', 190.03, 'product_image/family_pack.jpeg', 'cat_pro_ice_cream_007'),
('sub_cat_pro_ice_cream_002', 'Kulfi', 30, 'product_image/kulfi.jpeg', 'cat_pro_ice_cream_007'),
('sub_cat_pro_ice_cream_003', 'Cone', 50, 'product_image/cone.jpeg', 'cat_pro_ice_cream_007'),
('sub_cat_pro_lunch_001', 'Lunch(Limited)', 210, 'product_image/lunch_limited.jpeg', 'cat_pro_lunch_002'),
('sub_cat_pro_lunch_002', 'Lunch(unLimited)', 300, 'product_image/lunch_unlimit.jpeg', 'cat_pro_lunch_002'),
('sub_cat_pro_punjabi_thali_001', 'Punjabi_tadka(veg)', 360, 'product_image/punjabi_dish_veg.jpeg', 'cat_pro_punjabi_thali_005'),
('sub_cat_pro_punjabi_thali_002', 'punjabi_thali(nonveg)', 560, 'product_image/punjabi_nonveg.jpeg', 'cat_pro_punjabi_thali_005');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE IF NOT EXISTS `user_table` (
  `user_id` varchar(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_status` varchar(600) NOT NULL,
  `profile_pic` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `user_name`, `address`, `email_id`, `mobile_no`, `password`, `user_status`, `profile_pic`) VALUES
('00001 ', 'hiren ', 'surat ', 'patelhiren3792@gmail.com ', '7304507273', 'password ', 'good ', 'user_images/user-profile.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `company_registration`
--
ALTER TABLE `company_registration`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product_return`
--
ALTER TABLE `product_return`
  ADD PRIMARY KEY (`return_id`);

--
-- Indexes for table `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `rating_table`
--
ALTER TABLE `rating_table`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `sub_category_table`
--
ALTER TABLE `sub_category_table`
  ADD PRIMARY KEY (`subcat_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);
--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblemp`
--

CREATE TABLE IF NOT EXISTS `tblemp` (
  `ID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemp`
--

INSERT INTO `tblemp` (`ID`, `Name`, `Address`) VALUES
(1, 'moin', 'surat'),
(2, 'hi', 'hello'),
(3, 'anil', 'ss'),
(4, 'Nil', 'surat'),
(6, 'mm', 'ss'),
(8, 'f', 'f'),
(9, 'd', 'f'),
(10, 'k', 'h'),
(14, '', ''),
(15, '', ''),
(16, 'jj', 'k'),
(17, 'gg', 'jj'),
(18, 'jj', 'k'),
(19, 'jj', 'k'),
(20, 'jj', 'k'),
(21, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblemp`
--
ALTER TABLE `tblemp`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblemp`
--
ALTER TABLE `tblemp`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;--
-- Database: `emp_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE IF NOT EXISTS `emp` (
  `emp_id` int(100) NOT NULL,
  `emp_name` varchar(1000) NOT NULL,
  `emp_address` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `phpmyadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE IF NOT EXISTS `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE IF NOT EXISTS `pma__column_info` (
  `id` int(5) unsigned NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_coords`
--

CREATE TABLE IF NOT EXISTS `pma__designer_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `v` tinyint(4) DEFAULT NULL,
  `h` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE IF NOT EXISTS `pma__history` (
  `id` bigint(20) unsigned NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE IF NOT EXISTS `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) unsigned NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE IF NOT EXISTS `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{"db":"Myshoppy","table":"product_master"},{"db":"demo","table":"tblemp"},{"db":"Myshoppy","table":"customer_master"},{"db":"Myshoppy","table":"Wishlist_master"},{"db":"Myshoppy","table":"shoppingcart_master"},{"db":"EMP","table":"tblemp"},{"db":"tbldb","table":"db"},{"db":"demo","table":"database"},{"db":"MyTest","table":"EMP"},{"db":"emp_details","table":"emp"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE IF NOT EXISTS `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE IF NOT EXISTS `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float unsigned NOT NULL DEFAULT '0',
  `y` float unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE IF NOT EXISTS `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE IF NOT EXISTS `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'db_online_resturant', 'category_table', '{"sorted_col":"`category_table`.`cat_name` ASC"}', '2017-01-27 03:50:08'),
('root', 'Myshoppy', 'product_master', '{"CREATE_TIME":"2017-05-15 15:50:42","col_visib":["1","1","1","1","1","1","1","1","1","1","1","1","1"],"sorted_col":"`product_master`.`cat_id` DESC"}', '2017-05-27 05:14:16'),
('root', 'Myshoppy', 'shoppingcart_master', '{"sorted_col":"`cart_id` DESC"}', '2017-05-27 08:57:25'),
('root', 'Myshoppy', 'Wishlist_master', '{"sorted_col":"`Wishlist_master`.`wish_id` DESC"}', '2017-05-26 08:38:33');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE IF NOT EXISTS `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE IF NOT EXISTS `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2016-12-30 05:00:14', '{"collation_connection":"utf8mb4_unicode_ci"}');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_coords`
--
ALTER TABLE `pma__designer_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) unsigned NOT NULL AUTO_INCREMENT;--
-- Database: `tbldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `db`
--

CREATE TABLE IF NOT EXISTS `db` (
  `emp_id` int(10) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_add` varchar(100) NOT NULL,
  `emp_mob` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db`
--

INSERT INTO `db` (`emp_id`, `emp_name`, `emp_add`, `emp_mob`) VALUES
(1, 'hii', 'surat', '9876543210'),
(5, 'topstech', 'surat', '123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `db`
--
ALTER TABLE `db`
  ADD PRIMARY KEY (`emp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db`
--
ALTER TABLE `db`
  MODIFY `emp_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;--
-- Database: `tifflunbox`
--

-- --------------------------------------------------------

--
-- Table structure for table `Ragistration`
--

CREATE TABLE IF NOT EXISTS `Ragistration` (
  `user_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_img` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `pincoad` varchar(200) NOT NULL,
  `phno` varchar(200) NOT NULL,
  `identity` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Ragistration`
--

INSERT INTO `Ragistration` (`user_id`, `user_email`, `user_password`, `user_img`, `user_name`, `address`, `city`, `pincoad`, `phno`, `identity`) VALUES
(1, 'nikunj@gmail.com', 'Nik12345', 'rguser_img/58db54511478a.png', 'nikunj', 'Xyz', 'surat', '395004', '8153003181', ''),
(2, 'vivek@gmail.com', 'Vv123456', '', '', '', '', '', '', ''),
(3, 'vir@gmail.com', 'Vr123456', 'rguser_img/58e1dc7cdb42d.png', 'vir', 'xyz', 'surat', '395004', '1234567922', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `img_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `images` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`img_id`, `sp_id`, `images`) VALUES
(1, 1, 'images/58e33be501134.png'),
(2, 1, 'images/58e33bf4d6582.png'),
(3, 1, 'images/58e33c06e0c71.png'),
(4, 1, 'images/58e33c169bfda.png'),
(5, 1, 'images/58e33c274bc07.png');

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE IF NOT EXISTS `offer` (
  `offer_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `offer_name` varchar(50) NOT NULL,
  `offer_detail` varchar(50) NOT NULL,
  `offer_img` varchar(200) NOT NULL,
  `old_price` int(200) NOT NULL,
  `new_price` int(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offer_id`, `sp_id`, `offer_name`, `offer_detail`, `offer_img`, `old_price`, `new_price`) VALUES
(1, 1, 'Sunday spacial', 'This is Sunday spacial offer', 'offerimg/58e33b5573a6b.png', 12, 9),
(2, 1, 'Discount', 'Discount offer', 'offerimg/58e33bb95793e.png', 500, 450);

-- --------------------------------------------------------

--
-- Table structure for table `sp_ragistration`
--

CREATE TABLE IF NOT EXISTS `sp_ragistration` (
  `sp_id` int(200) NOT NULL,
  `sp_email` varchar(200) NOT NULL,
  `sp_username` varchar(200) NOT NULL,
  `sp_password` varchar(200) NOT NULL,
  `main_img` varchar(200) NOT NULL,
  `form_name` varchar(200) NOT NULL,
  `form_address` varchar(200) NOT NULL,
  `form_phoneno` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `pincoad` varchar(200) NOT NULL,
  `license` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_ragistration`
--

INSERT INTO `sp_ragistration` (`sp_id`, `sp_email`, `sp_username`, `sp_password`, `main_img`, `form_name`, `form_address`, `form_phoneno`, `street`, `city`, `pincoad`, `license`) VALUES
(1, 'nrs@gmail.com', 'nrs', 'Nrs12345', 'sp_img/58e3370ee7b13.png', 'GIUSEPPIS', '12 CHAINA TOEN ', '8153003181', 'katargam', 'surat', '395004', ''),
(2, 'Vir@gmail.com', 'vir', 'Vi123456', 'sp_img/58e33dee4954c.png', 'THE ROYAL CHEF', 'VALSAD', '9123451211', 'VALSAD', 'valsad', '', ''),
(3, 'rhs@gmail.com', 'Rhs', 'Rhs12345', 'sp_img/58e33ea0d935a.png', 'TOSCANA', 'AHEMDABAD', '8153000511', 'Setelite', 'Ahemdabad', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tiffin_categaries`
--

CREATE TABLE IF NOT EXISTS `tiffin_categaries` (
  `tc_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `tc_type` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiffin_categaries`
--

INSERT INTO `tiffin_categaries` (`tc_id`, `sp_id`, `tc_type`) VALUES
(1, 1, 'Gujarati'),
(2, 1, 'Panjabi'),
(3, 1, 'Italian');

-- --------------------------------------------------------

--
-- Table structure for table `tiffin_items`
--

CREATE TABLE IF NOT EXISTS `tiffin_items` (
  `item_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `tc_type` varchar(200) NOT NULL,
  `item_img` varchar(200) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_detail` varchar(200) NOT NULL,
  `item_price` int(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiffin_items`
--

INSERT INTO `tiffin_items` (`item_id`, `sp_id`, `tc_type`, `item_img`, `item_name`, `item_detail`, `item_price`) VALUES
(1, 1, 'Gujarati', 'item_images/58e3380332a49.png', 'Veg masala', 'Veg masala is Gujarati item ', 80),
(2, 1, 'Gujarati', 'item_images/58e3388780520.png', 'Gujarati raice', 'This is Gujarati raice', 50),
(3, 1, 'Gujarati', 'item_images/58e338b5f0493.png', 'Bengan masala', 'This is a bengan masala', 60),
(4, 1, 'Gujarati', 'item_images/58e3391177e60.png', 'Dal tadka with chilies', 'This is dal tadka', 130),
(5, 1, 'Gujarati', 'item_images/58e339790c1f0.png', 'Ali Gobi With bred', 'This is Ali gobi', 100),
(6, 1, 'Gujarati', 'item_images/58e339d035c7d.png', 'Alu Sabji', 'This is alu sabji', 60),
(7, 1, 'Panjabi', 'item_images/58e33a46600d3.png', 'Kaju kari', 'This is kaju kari', 140),
(8, 1, 'Panjabi', 'item_images/58e33a8d5f200.png', 'Punjabi raice', 'This is Punjabi raice', 100),
(9, 1, 'Panjabi', 'item_images/58e33ae149bb9.png', 'Punjabi roll', 'This is Punjabi roll', 220),
(10, 1, 'Italian', 'item_images/58e33cd677ae0.png', 'Focaccia Bread', 'This is Focaccia Bread', 450),
(11, 1, 'Italian', 'item_images/58e33d3daedb4.png', 'Veg burger', 'This is veg burger', 170);

-- --------------------------------------------------------

--
-- Table structure for table `user_msg`
--

CREATE TABLE IF NOT EXISTS `user_msg` (
  `msg_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_img` varchar(200) NOT NULL,
  `msg` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_msg`
--

INSERT INTO `user_msg` (`msg_id`, `sp_id`, `user_name`, `user_img`, `msg`) VALUES
(1, 1, 'nikunj', 'rguser_img/58db54511478a.png', 'This is good food provaider'),
(2, 1, 'nikunj', 'rguser_img/58db54511478a.png', 'good Gujarati items provid'),
(4, 2, 'vir', 'rguser_img/58e1dc7cdb42d.png', 'This is a fantastic food provider.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Ragistration`
--
ALTER TABLE `Ragistration`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `sp_ragistration`
--
ALTER TABLE `sp_ragistration`
  ADD PRIMARY KEY (`sp_id`);

--
-- Indexes for table `tiffin_categaries`
--
ALTER TABLE `tiffin_categaries`
  ADD PRIMARY KEY (`tc_id`);

--
-- Indexes for table `tiffin_items`
--
ALTER TABLE `tiffin_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user_msg`
--
ALTER TABLE `user_msg`
  ADD PRIMARY KEY (`msg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Ragistration`
--
ALTER TABLE `Ragistration`
  MODIFY `user_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `img_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
  MODIFY `offer_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sp_ragistration`
--
ALTER TABLE `sp_ragistration`
  MODIFY `sp_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tiffin_categaries`
--
ALTER TABLE `tiffin_categaries`
  MODIFY `tc_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tiffin_items`
--
ALTER TABLE `tiffin_items`
  MODIFY `item_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_msg`
--
ALTER TABLE `user_msg`
  MODIFY `msg_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
